drop table JobApplication;
drop table Internship;
drop table Job;
drop table Student;
drop table School;
drop table Recruiter;
drop table Company;